﻿using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using Microsoft.Xna.Framework;

/*
 * Following advice from the veteran devs, renamed a lot of things.
 * Keeping the doubles around so I don't have to deal with casting problems.
 */

namespace SimpleLevels
{
    class SimplePlayer : ModPlayer
    {
        public int level = 0;
        public double totalXP = 0;
        
        public double BoostPerLevel = 0.05;
        public int HPPerLevel = 10;
        public int ManaPerLevel = 2;
        public double Level0XP = 100;
        public double XPGrowth = 1.1;

        public override TagCompound Save()
        {
            return new TagCompound
            {
                {"level", level},
                {"xp", totalXP}
            };
        }

        public override void Load(TagCompound tag)
        {
            try
            {
                level = tag.GetInt("level");
                totalXP = tag.GetFloat("xp");
            }
            catch (SystemException e)
            {
                ErrorLogger.Log("@Level&XP :: " + e.ToString());
            }
        }

        /*
         * Idk why the while block is so poorly viewed, I don't value recursion enough to use it here.
         * And having my worries about a possible stack overflow being dismissed as "it'll never happen" didn't feel right.
         * Now if the player earns enough xp to level up multiple times we won't have a stream of level up messages.
         */

        public double GetNextLevelXP()
        {
            return Level0XP * Math.Pow(XPGrowth, (double)level);
        }

        public int GetCurrentLevel()
        {
            int i = level;
            while (totalXP > GetNextLevelXP())
            {
                totalXP -= GetNextLevelXP();
                i++;
            }
            return i;
        }

        public void AddXP(double XP)
        {
            totalXP += XP;
            if (totalXP > GetNextLevelXP())
            {
                level = GetCurrentLevel();
                Main.NewText("You're now level " + level + "!", 63, 255, 63);
            }
        }

        /*
         * This isn't boosting the damage of shield bashing, slime stomping and sentries. Not much I can do.
         */

        public void BoostIt(ref int damage)
        {
            damage = (int)(damage * (1.0 + BoostPerLevel * level));
        }

        
        public override void ModifyHitNPC(Item item, NPC target, ref int damage, ref float knockback, ref bool crit)
        {
            BoostIt(ref damage);
        }

        public override void ModifyHitNPCWithProj(Projectile proj, NPC target, ref int damage, ref float knockback, ref bool crit, ref int hitDirection)
        {
            BoostIt(ref damage);
        }
        
        public override void ModifyHitPvp(Item item, Player target, ref int damage, ref bool crit)
        {
            BoostIt(ref damage);
        }

        public override void ModifyHitPvpWithProj(Projectile proj, Player target, ref int damage, ref bool crit)
        {
            BoostIt(ref damage);
        }

        /*
         * There is a cap of 400 mana on the player.
         * And individually boosting each of the player's damage types isn't resulting in the amount I expected.
         * No clue if there's a cap on these as well.
         */

        public override void PreUpdateBuffs()
        {
            Main.LocalPlayer.statLifeMax2 += HPPerLevel * level;
            Main.LocalPlayer.statManaMax2 += ManaPerLevel * level;
        }
        
        public override void PostUpdateEquips()
        {
            Main.LocalPlayer.statDefense = (int)(Main.LocalPlayer.statDefense*(1.0 + BoostPerLevel * level));
        }
    }
}
