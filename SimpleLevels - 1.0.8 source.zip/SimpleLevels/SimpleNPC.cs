using Microsoft.Xna.Framework;
using System;
using Terraria;
using Terraria.ModLoader;

/*
 * Calculating and awarding xp each time something dies.
 * XP is only awarded if at least one player participated in killing the npc.
 */

namespace SimpleLevels
{
    public class SimpleNPC : GlobalNPC
	{
        public override bool InstancePerEntity
		{
			get
			{
				return true;
			}
		}

		public override void NPCLoot(NPC npc)
		{
            double XP;

            if (npc.defense == 0)
                XP = Math.Max(npc.lifeMax * npc.damage / 100d, 1);
            else
                XP = Math.Max(npc.lifeMax * npc.defense * npc.damage / 100d, 1);

            if (npc.lastInteraction != 255)
            {
                if (Main.netMode == 2)
                {
                    ModPacket packet = mod.GetPacket();
                    packet.Write((byte)SimpleLevels.Message.AddXP);
                    packet.Write(XP);
                    packet.Send();
                }
                else if (Main.netMode == 0)
                {
                    Main.LocalPlayer.GetModPlayer<SimplePlayer>().AddXP(XP);
                }
            }
        }
	}
}
